package com.lms.bean;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "approved_loans")
public class ApprovedLoans 
{
	@Id
	@GeneratedValue
	private int tempId;
	
	@OneToOne(cascade=CascadeType.PERSIST, fetch=FetchType.LAZY)
	@JoinColumn(name="applicationId")
	private LoanApplication approvedLoan;
	
	@Column(length=20)
	private String customerNameString;
	 private int amountOfLoanGranted;
	 private int monthlyInstallment;
	 private int yearsTimePeriod;
	 private int downPayement;
	 private int rateOfInterest;
	 private int totalAmountPayable;
	 
	public ApprovedLoans()
	{
		super();
	}

	public ApprovedLoans(int tempId, LoanApplication approvedLoan,
			String customerNameString, int amountOfLoanGranted,
			int monthlyInstallment, int yearsTimePeriod, int downPayement,
			int rateOfInterest, int totalAmountPayable) {
		super();
		this.tempId = tempId;
		this.approvedLoan = approvedLoan;
		this.customerNameString = customerNameString;
		this.amountOfLoanGranted = amountOfLoanGranted;
		this.monthlyInstallment = monthlyInstallment;
		this.yearsTimePeriod = yearsTimePeriod;
		this.downPayement = downPayement;
		this.rateOfInterest = rateOfInterest;
		this.totalAmountPayable = totalAmountPayable;
	}

	public int getTempId() {
		return tempId;
	}

	public void setTempId(int tempId) {
		this.tempId = tempId;
	}

	public LoanApplication getApprovedLoan() {
		return approvedLoan;
	}

	public void setApprovedLoan(LoanApplication approvedLoan) {
		this.approvedLoan = approvedLoan;
	}

	public String getCustomerNameString() {
		return customerNameString;
	}

	public void setCustomerNameString(String customerNameString) {
		this.customerNameString = customerNameString;
	}

	public int getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}

	public void setAmountOfLoanGranted(int amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}

	public int getMonthlyInstallment() {
		return monthlyInstallment;
	}

	public void setMonthlyInstallment(int monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	public int getYearsTimePeriod() {
		return yearsTimePeriod;
	}

	public void setYearsTimePeriod(int yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}

	public int getDownPayement() {
		return downPayement;
	}

	public void setDownPayement(int downPayement) {
		this.downPayement = downPayement;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public int getTotalAmountPayable() {
		return totalAmountPayable;
	}

	public void setTotalAmountPayable(int totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}

	
}

