package com.lms.exception;

public class LmsException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 4239628509913588556L;

public LmsException(String message) {
	super(message);
}
}
