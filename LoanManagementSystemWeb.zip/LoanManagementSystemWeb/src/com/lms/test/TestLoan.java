package com.lms.test;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.lms.bean.LoanApplication;
import com.lms.dao.CustomerDaoImpl;
import com.lms.dao.ICustomerDao;
import com.lms.exception.LmsException;

public class TestLoan {
	

static ICustomerDao customerDao =null;
	
	@BeforeClass
	public static void initialize() throws Exception {
		customerDao= new CustomerDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
	}

	
	
	@Test
	public void testview() {
		
		
		try {
			
			assertNotNull(customerDao.viewAll());
		} catch (LmsException e) {
			e.getMessage();
		}
	}
	
	@Test
	public void testApplyLoan() {
		
		
		try {
			Date newDate = new Date();
			System.out.println(newDate);
			LoanApplication loan = new LoanApplication();
			loan.setAddressOfProperty("ghnghdfs");
			loan.setAmountOfLoan(400000.00);
			loan.setAnnualFamilyIncome(1500000);
			loan.setApplicationDate(newDate);
			loan.setApplicationId(6);
			loan.setApprovedLoan(null);
			loan.setDocumentProofsAvailable(null);
			loan.setMarketValueOfGuranteeCover(0);
			loan.setCustomer(null);
			loan.setDateOfInterview(newDate);
			loan.setApprovedLoan(null);
			loan.setGuranteeCover("House");
			
			assertNotNull(customerDao.applyLoan(loan,11));
		
		} catch (Exception e) {
			e.getMessage();
		}
	}
	
	/*@Test
	public void testValidLadLogin() {
		String[] credential = {"abc","abc123","lad"};
		
		try {
			
			assertTrue(userDao.authenticUser(credential));
		} catch (LmsException e) {
			System.err.println("Invalid lad details in junit "+e.getMessage());
		}
	}
*/
}
